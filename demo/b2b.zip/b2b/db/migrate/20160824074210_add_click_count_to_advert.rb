class AddClickCountToAdvert < ActiveRecord::Migration[5.0]
  def change
    add_column :ads , :click_count , :integer #广告点击记录
  end
end
