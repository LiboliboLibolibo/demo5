#产品类别
class CreateMerchantCategories < ActiveRecord::Migration[5.0]
  def change
    create_table :merchant_categories do |t|
      t.string    :name #名称
      t.integer   :parent_id , index:true #父类ID
      t.timestamps
    end
  end
end
