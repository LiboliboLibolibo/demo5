class CreateAdCategories < ActiveRecord::Migration[5.0]
  def change
    create_table :ad_categories do |t|
      t.string    :ad_type #广告位规格
      t.timestamps
    end
  end
end
