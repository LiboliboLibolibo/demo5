class ChangePharmacyNameFromMerchant < ActiveRecord::Migration[5.0]
  def change
    rename_column :merchants , :pharmacy_type_id , :pharmacy_type_category_id
    rename_column :merchants , :category_id , :merchant_category_id
  end
end
