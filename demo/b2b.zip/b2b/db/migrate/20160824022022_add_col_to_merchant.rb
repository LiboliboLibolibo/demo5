class AddColToMerchant < ActiveRecord::Migration[5.0]
  def change
    add_column :merchants , :status , :integer #上架状态，0下架 1上架
    add_column :merchants , :generic_name , :string #通用名称
    add_column :merchants , :max_order_number , :integer #最大购买数量
    add_column :merchants , :min_order_number , :integer #最小购买数量
  end
end
