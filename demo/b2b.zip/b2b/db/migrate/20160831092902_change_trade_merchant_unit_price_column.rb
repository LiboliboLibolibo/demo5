class ChangeTradeMerchantUnitPriceColumn < ActiveRecord::Migration[5.0]
  def change
    remove_column :trade_merchants, :unit_price
    add_column :trade_merchants, :unit_price, :float
  end
end
