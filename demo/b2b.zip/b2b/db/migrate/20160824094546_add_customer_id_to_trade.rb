class AddCustomerIdToTrade < ActiveRecord::Migration[5.0]
  def change
    add_column  :trades , :customer_id  , :integer
    add_index   :trades , :customer_id
  end
end
