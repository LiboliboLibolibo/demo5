#销售控制类别：整件 | 中包装 | 拆零
class CreateSellCategories < ActiveRecord::Migration[5.0]
  def change
    create_table :sell_categories do |t|
      t.string    :name #名称
      t.timestamps
    end
  end
end
