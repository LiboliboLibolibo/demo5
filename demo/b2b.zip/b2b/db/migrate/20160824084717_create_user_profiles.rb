class CreateUserProfiles < ActiveRecord::Migration[5.0]
  def change
    create_table :user_profiles do |t|
      t.integer :user_id , index:true #用户ID
      t.float   :balance # 用户余额
      t.float   :point   # 用户积分
      t.integer :level   # 用户等级
      t.integer :quota   # 用户配额

      t.timestamps
    end
  end
end
