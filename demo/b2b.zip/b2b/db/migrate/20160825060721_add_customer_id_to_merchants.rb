class AddCustomerIdToMerchants < ActiveRecord::Migration[5.0]
  def change
    add_column  :merchants , :customer_id  , :integer
    add_index   :merchants , :customer_id
  end
end
