class CreateCompanies < ActiveRecord::Migration[5.0]
  def change
    create_table :companies do |t|
      t.integer  :user_id , index:true #用户ID
      t.string   :contact  #联系人
      t.string   :tel  #座机号
      t.integer  :company_category_id , index:true #公司类别
      t.string   :email  #邮件
      t.string   :buyer  #采购员
      t.string   :phone  #手机
      t.string   :taxpayer_identification_number  #纳税人识别号
      t.integer  :receipt_category_id , index:true #发票类型ID
      t.string   :bank  #开户银行
      t.string   :bank_account  #开户账号
      t.string   :account_holder  #开户人
      t.string   :account_name  #开户名称
      t.string   :legal_person  #法人
      t.date     :legal_order_effective_date  #法人委托书生效日期
      t.date     :legal_order_failure_date  #法人委托书失效日期
      t.string   :business_license_number  #经营许可证证号
      t.date     :business_license_effective_date  #经营许可证生效日期
      t.date     :business_license_failure_date  #经营许可证失效日期
      t.string   :business_card_number  #营业证号
      t.date     :business_card_effective_date  #营业证发证日期
      t.date     :business_card_failure_date  #营业证失效日期
      t.string   :gsp_card_number  #GSP证号
      t.date     :gsp_card_effective_date  #GSP证生效日期
      t.date     :gsp_card_card_failure_date  #GSP证失效日期
      t.timestamps
    end
  end
end
