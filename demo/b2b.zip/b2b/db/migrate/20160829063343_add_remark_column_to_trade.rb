class AddRemarkColumnToTrade < ActiveRecord::Migration[5.0]
  def change
    add_column  :trades , :remark  , :string
  end
end
