#药剂类别
class CreatePharmacyTypeCategories < ActiveRecord::Migration[5.0]
  def change
    create_table :pharmacy_type_categories do |t|
      t.string    :name #名称
      t.timestamps
    end
  end
end
