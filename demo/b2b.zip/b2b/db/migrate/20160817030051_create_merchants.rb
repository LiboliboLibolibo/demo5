#产品
class CreateMerchants < ActiveRecord::Migration[5.0]
  def change
    create_table :merchants do |t|
      t.string   :name  #名称
      t.integer  :brand_id , index:true #品牌ID
      t.string   :approval_number #批准文号
      t.string   :functional_therapy  #功能主治
      t.string   :ingredients  #成份
      t.string   :usage_dosage  #用法用量
      t.integer  :category_id , index:true #类别ID
      t.integer  :pharmacy_type_id , index:true #剂型ID
      t.integer  :otc  #是否处方药
      t.integer  :sell_category_id , index:true #销售控制类别ID
      t.string   :picture  #产品图片
      t.integer  :description #产品说明
      t.float    :price  #产品单价
      t.integer  :stock_count #产品库存
      t.string   :sell_area  #招商区域
      t.float    :scan_count  #浏览次数
      t.timestamps
    end
  end
end
