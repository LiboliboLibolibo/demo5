class CreateUserBrands < ActiveRecord::Migration[5.0]
  def change
    create_table :user_brands do |t|
      t.integer  :brand_id , index:true #品牌ID
      t.integer  :user_id , index:true #用户ID
      t.timestamps
    end
  end
end
