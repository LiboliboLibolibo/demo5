class AddSpecificationToMerchant < ActiveRecord::Migration[5.0]
  def change
    add_column :merchants , :specification , :string #规格
  end
end
