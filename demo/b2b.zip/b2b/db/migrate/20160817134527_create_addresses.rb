class CreateAddresses < ActiveRecord::Migration[5.0]
  def change
    create_table :addresses do |t|
      t.integer  :company_id , index:true #公司ID
      t.string   :receiver #收货人
      t.string   :phone #收货人手机
      t.string   :province #省份
      t.string   :city #城市
      t.string   :area #区域
      t.string   :street #街道地址
      t.string   :post_code #邮政编码
      t.timestamps
    end
  end
end
