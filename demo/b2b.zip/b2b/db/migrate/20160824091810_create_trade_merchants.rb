class CreateTradeMerchants < ActiveRecord::Migration[5.0]
  def change
    create_table :trade_merchants do |t|
      t.integer     :trade_id , index:true
      t.integer     :totals
      t.integer     :unit_price
      t.timestamps
    end
    add_column  :trades , :final_price , :float
    add_index :trades , :user_id 
    add_index :trades , :status_id
  end
end
