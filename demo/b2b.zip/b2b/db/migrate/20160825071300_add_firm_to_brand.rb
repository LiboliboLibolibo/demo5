class AddFirmToBrand < ActiveRecord::Migration[5.0]
  def change
    add_column  :brands , :firm  , :string
    remove_column :brands , :company_id
  end
end
