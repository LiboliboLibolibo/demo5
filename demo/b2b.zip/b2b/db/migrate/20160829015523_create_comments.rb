class CreateComments < ActiveRecord::Migration[5.0]
  def change
    create_table :comments do |t|
      t.integer :merchant_id, index:true
      t.integer :user_id,index:true
      t.integer :trade_id,index:true
      t.text :content
      t.datetime :publish_time
      t.integer :star
      t.timestamps
    end
  end
end
