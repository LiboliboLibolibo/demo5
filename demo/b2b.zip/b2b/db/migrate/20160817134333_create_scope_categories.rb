class CreateScopeCategories < ActiveRecord::Migration[5.0]
  def change
    create_table :scope_categories do |t|
      t.string    :name #名称
      t.timestamps
    end
  end
end
