class AddCompanyIdToBrand < ActiveRecord::Migration[5.0]
  def change
    add_column :brands , :company_id , :integer
    # drop_table :company_brands
  end
end
