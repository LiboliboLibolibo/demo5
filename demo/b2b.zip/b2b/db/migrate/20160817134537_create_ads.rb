class CreateAds < ActiveRecord::Migration[5.0]
  def change
    create_table :ads do |t|
      t.string    :pic #广告图片
      t.string    :url #跳转URL
      t.integer   :ad_category_id , index:true #类别ID
      t.timestamps
    end
  end
end
