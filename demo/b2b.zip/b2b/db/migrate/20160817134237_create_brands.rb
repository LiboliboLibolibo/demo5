#产品品牌
class CreateBrands < ActiveRecord::Migration[5.0]
  def change
    create_table :brands do |t|
      t.string    :name #名称
      t.text    :decription #描述
      t.string    :logo #品牌LOGO
      t.timestamps
    end
  end
end
