class CreateCompanyScopes < ActiveRecord::Migration[5.0]
  def change
    create_table :company_scopes do |t|
      t.integer  :scope_category_id , index:true #经营类别ID
      t.integer  :company_id , index:true #公司ID
      t.timestamps
    end
  end
end
