class CreateTrades < ActiveRecord::Migration[5.0]
  def change
    create_table :trades do |t|
      t.integer     :user_id
      t.integer     :trade_number #订单
      t.integer     :trace_number #运单
      t.float       :total_price
      t.integer     :status_id
      t.timestamps
    end
  end
end
