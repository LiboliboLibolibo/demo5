class CreateUsers < ActiveRecord::Migration[5.0]
  def change
    create_table :users do |t|
      t.string  :name
      t.string  :password_digest
      t.integer :user_group_id  , index: true
      t.integer :status_id  , index:true
      t.timestamps
    end
  end
end
