# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160831092902) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "ad_categories", force: :cascade do |t|
    t.string   "ad_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string   "position"
  end

  create_table "addresses", force: :cascade do |t|
    t.integer  "company_id"
    t.string   "receiver"
    t.string   "phone"
    t.string   "province"
    t.string   "city"
    t.string   "area"
    t.string   "street"
    t.string   "post_code"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["company_id"], name: "index_addresses_on_company_id", using: :btree
  end

  create_table "ads", force: :cascade do |t|
    t.string   "pic"
    t.string   "url"
    t.integer  "ad_category_id"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.integer  "click_count"
    t.index ["ad_category_id"], name: "index_ads_on_ad_category_id", using: :btree
  end

  create_table "articles", force: :cascade do |t|
    t.string   "title"
    t.datetime "publish_time"
    t.text     "content"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
  end

  create_table "brands", force: :cascade do |t|
    t.string   "name"
    t.text     "decription"
    t.string   "logo"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.string   "firm"
    t.string   "picture_url"
  end

  create_table "ckeditor_assets", force: :cascade do |t|
    t.string   "data_file_name",               null: false
    t.string   "data_content_type"
    t.integer  "data_file_size"
    t.integer  "assetable_id"
    t.string   "assetable_type",    limit: 30
    t.string   "type",              limit: 30
    t.integer  "width"
    t.integer  "height"
    t.datetime "created_at",                   null: false
    t.datetime "updated_at",                   null: false
    t.index ["assetable_type", "assetable_id"], name: "idx_ckeditor_assetable", using: :btree
    t.index ["assetable_type", "type", "assetable_id"], name: "idx_ckeditor_assetable_type", using: :btree
  end

  create_table "comments", force: :cascade do |t|
    t.integer  "merchant_id"
    t.integer  "user_id"
    t.integer  "trade_id"
    t.text     "content"
    t.datetime "publish_time"
    t.integer  "star"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
    t.index ["merchant_id"], name: "index_comments_on_merchant_id", using: :btree
    t.index ["trade_id"], name: "index_comments_on_trade_id", using: :btree
    t.index ["user_id"], name: "index_comments_on_user_id", using: :btree
  end

  create_table "companies", force: :cascade do |t|
    t.integer  "user_id"
    t.string   "contact"
    t.string   "tel"
    t.integer  "company_category_id"
    t.string   "email"
    t.string   "buyer"
    t.string   "phone"
    t.string   "taxpayer_identification_number"
    t.integer  "receipt_category_id"
    t.string   "bank"
    t.string   "bank_account"
    t.string   "account_holder"
    t.string   "account_name"
    t.string   "legal_person"
    t.date     "legal_order_effective_date"
    t.date     "legal_order_failure_date"
    t.string   "business_license_number"
    t.date     "business_license_effective_date"
    t.date     "business_license_failure_date"
    t.string   "business_card_number"
    t.date     "business_card_effective_date"
    t.date     "business_card_failure_date"
    t.string   "gsp_card_number"
    t.date     "gsp_card_effective_date"
    t.date     "gsp_card_card_failure_date"
    t.datetime "created_at",                      null: false
    t.datetime "updated_at",                      null: false
    t.string   "name"
    t.integer  "default_address_id"
    t.index ["company_category_id"], name: "index_companies_on_company_category_id", using: :btree
    t.index ["receipt_category_id"], name: "index_companies_on_receipt_category_id", using: :btree
    t.index ["user_id"], name: "index_companies_on_user_id", using: :btree
  end

  create_table "company_categories", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "company_scopes", force: :cascade do |t|
    t.integer  "scope_category_id"
    t.integer  "company_id"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
    t.index ["company_id"], name: "index_company_scopes_on_company_id", using: :btree
    t.index ["scope_category_id"], name: "index_company_scopes_on_scope_category_id", using: :btree
  end

  create_table "merchant_categories", force: :cascade do |t|
    t.string   "name"
    t.integer  "parent_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["parent_id"], name: "index_merchant_categories_on_parent_id", using: :btree
  end

  create_table "merchants", force: :cascade do |t|
    t.string   "name"
    t.integer  "brand_id"
    t.string   "approval_number"
    t.string   "functional_therapy"
    t.string   "ingredients"
    t.string   "usage_dosage"
    t.integer  "merchant_category_id"
    t.integer  "pharmacy_type_category_id"
    t.integer  "otc"
    t.integer  "sell_category_id"
    t.string   "picture"
    t.float    "price"
    t.integer  "stock_count"
    t.string   "sell_area"
    t.float    "scan_count"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.integer  "status_id"
    t.string   "generic_name"
    t.integer  "max_order_number"
    t.integer  "min_order_number"
    t.string   "specification"
    t.integer  "customer_id"
    t.text     "description"
    t.index ["brand_id"], name: "index_merchants_on_brand_id", using: :btree
    t.index ["customer_id"], name: "index_merchants_on_customer_id", using: :btree
    t.index ["merchant_category_id"], name: "index_merchants_on_merchant_category_id", using: :btree
    t.index ["pharmacy_type_category_id"], name: "index_merchants_on_pharmacy_type_category_id", using: :btree
    t.index ["sell_category_id"], name: "index_merchants_on_sell_category_id", using: :btree
  end

  create_table "pharmacy_type_categories", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "receipt_categories", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "scope_categories", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "sell_categories", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "trade_merchants", force: :cascade do |t|
    t.integer  "trade_id"
    t.integer  "totals"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "merchant_id"
    t.float    "unit_price"
    t.index ["trade_id"], name: "index_trade_merchants_on_trade_id", using: :btree
  end

  create_table "trades", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "trade_number"
    t.integer  "trace_number"
    t.float    "total_price"
    t.integer  "status_id"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
    t.float    "final_price"
    t.integer  "customer_id"
    t.string   "remark"
    t.integer  "address_id"
    t.index ["customer_id"], name: "index_trades_on_customer_id", using: :btree
    t.index ["status_id"], name: "index_trades_on_status_id", using: :btree
    t.index ["user_id"], name: "index_trades_on_user_id", using: :btree
  end

  create_table "user_brands", force: :cascade do |t|
    t.integer  "brand_id"
    t.integer  "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["brand_id"], name: "index_user_brands_on_brand_id", using: :btree
    t.index ["user_id"], name: "index_user_brands_on_user_id", using: :btree
  end

  create_table "user_groups", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "user_profiles", force: :cascade do |t|
    t.integer  "user_id"
    t.float    "balance"
    t.float    "point"
    t.integer  "level"
    t.integer  "quota"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_user_profiles_on_user_id", using: :btree
  end

  create_table "users", force: :cascade do |t|
    t.string   "name"
    t.string   "password_digest"
    t.integer  "user_group_id"
    t.integer  "status_id"
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
    t.index ["status_id"], name: "index_users_on_status_id", using: :btree
    t.index ["user_group_id"], name: "index_users_on_user_group_id", using: :btree
  end

end
