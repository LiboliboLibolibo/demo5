# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
UserGroup.delete_all
UserGroup.create([
  {id: 1 , name: '管理员'}  ,
  {id: 2 , name: '制药厂'}  ,
  {id: 3 , name: '代理商'}  ,
  {id: 4 , name: '业务员'}  ,
  {id: 5 , name: '医药公司'}  ,
  {id: 6 , name: '医院'}  ,
  {id: 7 , name: '药店'}  ,
  {id: 8 , name: '银行'}  ,
])
CompanyCategory.delete_all
CompanyCategory.create([
  {id: 1 , name: '商业公司'}  ,
  {id: 2 , name: '连锁药店'}  ,
  {id: 3 , name: '单体药店'}  ,
  {id: 4 , name: '个体医疗'}  ,
  {id: 5 , name: '专科医院'}  ,
  {id: 6 , name: '卫生院'}  ,
  {id: 7 , name: '综合性医院'}  ,
])
ReceiptCategory.delete_all
ReceiptCategory.create([
   {id: 1 , name: '普通发票'}  ,
   {id: 2 , name: '增值税发票'}  ,
])
MerchantCategory.delete_all
MerchantCategory.create([
   {id: 1 , parent_id: 0,name: '中药'}  ,
   {id: 2 , parent_id: 1,name: '中成药'}  ,
])
PharmacyTypeCategory.delete_all
PharmacyTypeCategory.create([
   {id: 1 , name: '丸剂'}  ,
   {id: 2 , name: '片剂'}  ,
   {id: 3 , name: '颗粒剂'}  ,
   {id: 4 , name: '洗剂'}  ,
   {id: 5 , name: '散剂'}  ,
   {id: 6 , name: '粉针剂'}  ,
   {id: 7 , name: '针剂'}  ,
   {id: 8 , name: '注射剂'}  ,
])
SellCategory.delete_all
SellCategory.create([
    {id: 1 ,name: '整件'}  ,
    {id: 2 ,name: '中包装'}  ,
    {id: 3 ,name: '拆零'}  ,
])
# ÷Brand.delete_all

Brand.create ([
    {name: '同仁堂' ,picture_url: 'http://img.800pharm.com/images/20160223/20160223103312_73.jpg'}  ,
    {name: '白云山' ,picture_url: 'http://img.800pharm.com/images/20160223/20160223103432_82.jpg'}  ,
    {name: '陈李济' ,picture_url: 'http://img.800pharm.com/images/20160223/20160223103506_462.jpg'}  ,
    {name: 'durex' ,picture_url: 'http://img.800pharm.com/images/20160203/20160203155906_809.jpg'}  ,
    {name: '东阿阿胶',picture_url: '	http://img.800pharm.com/images/20160223/20160223103600_652.jpg'}  ,
    {name: 'pfzer' ,picture_url: 'http://img.800pharm.com/images/20160223/20160223103630_801.jpg'}  ,
    {name: '汇仁集团' ,picture_url: '	http://img.800pharm.com/images/20160223/20160223103659_438.jpg'}  ,
    {name: '惠氏' ,picture_url: 'http://img.800pharm.com/images/20160223/20160223103730_224.jpg'}  ,
    {name: 'omron' ,picture_url: 'http://img.800pharm.com/images/20160223/20160223103810_439.jpg'}  ,
    {name: '汤臣倍健' ,picture_url: '	http://img.800pharm.com/images/20160223/20160223103845_279.jpg'}  ,
    {name: '修正',picture_url: '	http://img.800pharm.com/images/20160223/20160223103923_915.jpg'}  ,
    {name: '三九药业' ,picture_url: '	http://img.800pharm.com/images/20160223/20160223103953_137.jpg'}  ,
])




# User.create({id: 1 , name: 'admin' , password: Digest::MD5.hexdigest('msadmin') , user_group_id: 1})
