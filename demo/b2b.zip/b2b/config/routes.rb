Rails.application.routes.draw do
  mount Ckeditor::Engine => '/ckeditor'
  root "merchants#welcome"

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  resources :users do
    collection do
      get 'login','register'
    end
  end

  resources :merchants do
    collection do
      get 'welcome'
    end
  end

  resources :login do
    collection do
      get :logout
    end
  end

  resources :trades do
    collection do
      post 'pay','delivery','received','received_back'
    end
  end

  resources :shoppings do
    collection do
      get 'car','order'
    end
  end

  resources :registers
  resources :merchant_trades


  namespace :admin do
    root 'login#index'
    resources :users
    resources :user_groups
    resources :adverts
    resources :advert_categories
    resources :companies
    resources :company_categories
    resources :receipt_categories
    resources :scope_categories
    resources :addresses
    resources :brands
    resources :sell_categories
    resources :merchant_categories
    resources :pharmacy_type_categories
    resources :merchants
    resources :trades
    resources :articles
    resources :user_brands
    resources :verify_users
    resources :comments
    resources :login do
      collection do
        get :logout
      end
    end
  end
end
