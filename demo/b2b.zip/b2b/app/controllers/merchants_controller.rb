class MerchantsController < ApplicationController
  layout :false
  def welcome

  end

  def index
    @merchants = Merchant.all
    @merchants = @merchants.where("name like '%?%'" , params[:title]) unless params[:title].blank?
    @merchants = @merchants.where(merchant_category_id: params[:merchant_category_id]) unless params[:merchant_category_id].blank?
    @merchants = @merchants.where(brand_id: params[:brand_id]) unless  params[:brand_id].blank?
    @merchants = @merchants.where(pharmacy_type_category_id: params[:pharmacy_type_category_id]) unless params[:pharmacy_type_category_id].blank?
    @merchants = @merchants.page(params[:page]).per(10)
    render layout:false
  end
  def show
    @merchant = Merchant.find params[:id]
    render layout: false
  end
end
