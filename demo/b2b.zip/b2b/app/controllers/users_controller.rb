class UsersController < ApplicationController
  layout :false
  def index
  end

  def login
  end

  def register
  end
end
