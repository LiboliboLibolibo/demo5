class ShoppingsController < ApplicationController

  layout :false

  #购物车
  def car
    @trade = Trade.where(user_id:current_user.id,status_id:1).take
    if !@trade.nil?
      @trade_merchants = TradeMerchant.where(trade_id: @trade.id)
    end
  end

  #订货列表
  def order
    @trades = Trade.where(user_id: current_user.id).order('id desc').page params[:page]

    @status_id = params[:status_id]

    if !@status_id.nil?
      p @status_id
      @trades = Trade.where(user_id: current_user.id,status_id: @status_id).order('id desc').page params[:page]
    end

  end

end
