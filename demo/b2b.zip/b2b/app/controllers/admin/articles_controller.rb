class Admin::ArticlesController < Admin::ApplicationController

  def index
    if current_user.admin_role?
      @articles = Article.order(:id).page(params[:page]).per(20)
    end
  end

  def new
    @article = Article.new
  end

  def create
    if current_user.admin_role?

      article = Article.new data_permit

      article['publish_time'] = (Time.now).strftime("%Y-%m-%d %H:%M:%S")

      if article.save
        redirect_to :controller => 'articles'
      else
        render json: {errors: article.errors.full_messages.to_s }
      end

    end
  end

  def edit
    @article = Article.find params[:id]
  end

  def update
    @article = Article.find params[:id]
    if @article.update(data_permit)
      redirect_to :controller => 'articles'
    else
      render json: {errors: @article.errors.full_messages.to_s }
    end
  end

  def destroy
    article = Article.find params[:id]
    if article.delete
      redirect_to :controller => 'articles'
    else
      render json: {errors: article.errors.full_messages.to_s}
    end
  end

  private

    def data_permit
      params.require(:article).permit(Article.attribute_names)
    end

end
