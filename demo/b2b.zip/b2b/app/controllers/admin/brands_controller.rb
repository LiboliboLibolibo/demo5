class Admin::BrandsController < Admin::ApplicationController

  def index
    @brands = Brand.order(:id).page(params[:page]).per(20)
  end

  def new
    @brand = Brand.new
  end

  def show
    @company =  Company.find(params[:id])
    @brands = Brand.where(company_id: params[:id]).order(:id).page(params[:page]).per(20)
  end

  def create
    brand = Brand.new data_permit
    if brand.save
      redirect_to :controller => 'brands'
    else
      render json: {errors: brand.errors.full_messages.to_s}
    end
  end

  def edit
    @brand = Brand.find params[:id]
  end

  def update
    @brand = Brand.find params[:id]
    if @brand.update(data_permit)
      redirect_to :controller => 'brands'
    else
      render json: {errors: @brand.errors.full_messages.to_s }
    end
  end

  def destroy
    brand = Brand.find params[:id]
    if brand.delete
      render json: {success: true}
    else
      render json: {errors: brand.errors.full_messages.to_s}
    end
  end

  private
  def data_permit
    params.require(:brand).permit(Brand.attribute_names)
  end
end
