class Admin::VerifyUsersController < ApplicationController
  def index
    if current_user.admin_role?
      user = User.find params['user_id']
      user.update(status_id: 2)
      p user.errors
    else
      p 'only admin role can verify users!'
    end

    redirect_to controller: 'users'
  end
end
