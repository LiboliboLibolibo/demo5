class Admin::CompaniesController < Admin::ApplicationController

  def index
    if current_user.admin_role?
      @companies = Company.order(:id).page(params[:page]).per(20)
    else
      @companies = Company.where(user_id: current_user.id).order(:id).page(params[:page]).per(20)
    end

  end

  def new
    @company = Company.new
  end

  def edit
    @company = Company.where(user_id: params[:id]).take
  end

  def update
    @company = Company.find params[:id]
    if @company.update(data_permit)
      redirect_to :controller => 'users'
    else
      render json: {errors: @company.errors.full_messages.to_s }
    end
  end

  def destroy
    company = Company.find params[:id]
    if company.delete
      render json: {success: true}
    else
      render json: {errors: company.errors.full_messages.to_s}
    end
  end

private

  def data_permit
    params.require(:company).permit(Company.attribute_names)
  end

end
