class Admin::AdvertCategoriesController < Admin::ApplicationController

  def index
    @categories = AdCategory.order(:id).page(params[:page]).per(20)
  end

  def create
    cate = AdCategory.new data_permit
    if cate.save
      render json: {success: true}
    else
      render json: {errors: cate.errors.full_messages.to_s}
    end
  end

  def destroy
    cate = AdCategory.find params[:id]

    if Ad.exists?(ad_category_id: cate.id)
      render json: {errors: '存在关联广告，无法删除'}
    elsif cate.delete
      render json: {success: true}
    else
      render json: {errors: cate.errors.full_messages.to_s}
    end
  end

  private
  def data_permit
    params.require(:data).permit(:ad_type , :position)
  end

end
