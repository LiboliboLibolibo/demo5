class Admin::UserBrandsController < Admin::ApplicationController
  def index
    @user_brands = current_user.user_brand

    brand_ids = current_user.user_brand.pluck :brand_id

    @brands = if brand_ids.empty?
                Brand.all
              else
                Brand.where('id NOT IN (?)', brand_ids)
              end
  end

  def create
    if current_user.admin_role?
      p 'admin cannot create brand relations!'
    else
      user_brand = UserBrand.new(user_id: current_user.id, brand_id: data_permit['brand_id'])
      if user_brand.save
        redirect_to controller: 'user_brands'
      else
        render json: { errors: user_brand.errors.full_messages.to_s }
      end
    end
  end

  def destroy
    brand = UserBrand.find params[:id]
    if brand.delete
      redirect_to controller: 'user_brands'
    else
      render json: { errors: brand.errors.full_messages.to_s }
    end
  end

  private

  def data_permit
    params.require(:user_brand).permit(:brand_id)
  end
end
