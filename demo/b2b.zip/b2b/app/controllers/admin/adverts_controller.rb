class Admin::AdvertsController < Admin::ApplicationController
  def index
    @categories = AdCategory.order(:id)
    @ads = Ad.order('id').page(params[:page]).per(20)
  end

  def create
    ad = Ad.new data_permit
    if ad.save
      redirect_to :controller => 'adverts'
    else
      render json: {errors: ad.errors.full_messages.to_s}
    end
  end

  def destroy
    ad = Ad.find params[:id]
    if ad.delete
      render json: {success: true}
    else
      render json: {errors: ad.errors.full_messages.to_s}
    end
  end

  private
  def data_permit
    params.require(:data).permit(:pic , :url , :ad_category_id)
  end
end
