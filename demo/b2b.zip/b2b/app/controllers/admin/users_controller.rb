class Admin::UsersController < Admin::ApplicationController
  def index
    @groups = UserGroup.order(:id)
    @users = User.includes(:user_group).order('id').page(params[:page]).per(20)
  end

  def create
    user = User.new data_permit

    if user.save
      Company.create user_id: user.id
      render json: { success: true }
    else
      render json: { errors: user.errors.full_messages.to_s }
    end
  end

  def destroy
    user = User.find params[:id]
    profile = user.user_profile
    company = user.company
    brand = user.user_brand

    if user.delete

      profile.delete
      company.delete
      brand.destroy(brand)

      render json: { success: true }
    else
      render json: { errors: user.errors.full_messages.to_s }
    end
  end

  private

  def data_permit
    params.require(:data).permit(:name, :password, :user_group_id)
  end
end
