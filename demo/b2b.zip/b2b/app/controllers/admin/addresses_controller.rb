class Admin::AddressesController < Admin::ApplicationController
  def index
    @addresses = Address.order(:id).page(params[:page]).per(20)
  end

  def show
    @company = Company.find(params[:id])
    @addresses = Address.where(company_id: params[:id]).order(:id).page(params[:page]).per(20)
  end

  def create
    addr = Address.new data_permit
    if addr.save
      render json: { success: true }
    else
      render json: { errors: addr.errors.full_messages.to_s }
    end
  end

  def destroy
    addr = Address.find params[:id]
    if addr.delete
      render json: { success: true }
    else
      render json: { errors: addr.errors.full_messages.to_s }
    end
  end

  private

  def data_permit
    params.require(:data).permit(Address.attribute_names)
  end
end
