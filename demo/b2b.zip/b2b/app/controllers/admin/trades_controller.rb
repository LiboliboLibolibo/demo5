class Admin::TradesController < Admin::ApplicationController
  def index
    if current_user.admin_role?
      @trades = Trade.order('id desc').page params[:page]
    elsif current_user.customer_role?
      @trades = Trade.where(customer_id: current_user.id).order('id desc').page params[:page]
    else
      @trades = Trade.where(user_id: current_user.id).order('id desc').page params[:page]
    end
  end
end
