class Admin::LoginController < ActionController::Base
  def index
    end

  def create
    user = User.find_by(name: params[:user_name]).try(:authenticate, params[:password])
    if user
      if user.verify? && !user.admin_role?
        render json: { errors: '用户未审核通过，请联系管理员' }
      else
        session[:user_id] = user.id
        render json: { success: true }
      end
    else
      render json: { errors: '用户名和密码不匹配' }
    end
  end

  def logout
    session[:user_id] = nil
    redirect_to admin_login_index_path
  end
end
