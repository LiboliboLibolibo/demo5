class Admin::SellCategoriesController < Admin::ApplicationController
  def index
    @categories = SellCategory.order(:id).page(params[:page]).per(20)
  end

  def create
    cate = SellCategory.new data_permit
    if cate.save
      render json: { success: true }
    else
      render json: { errors: cate.errors.full_messages.to_s }
    end
  end

  def destroy
    cate = SellCategory.find params[:id]

    if Merchant.exists?(sell_category_id: cate.id)
      render json: { errors: '存在关联商品，无法删除' }
    elsif cate.delete
      render json: { success: true }
    else
      render json: { errors: cate.errors.full_messages.to_s }
    end
  end

  private

  def data_permit
    params.require(:data).permit(:name)
  end
end
