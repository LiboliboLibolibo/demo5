class Admin::UserGroupsController < Admin::ApplicationController
  def index
    @groups = UserGroup.order(:id)
    status_id = params[:status_id]

    if status_id.nil?
      @users = User.includes(:user_group).order('id').page(params[:page]).per(20)
    else
      @users = User.includes(:user_group).where(status_id: status_id).order('id').page(params[:page]).per(20)
    end
  end

  def show
    @groups = UserGroup.order(:id)
    @users = User.includes(:user_group).where(user_group_id: params[:id]).order('id').page(params[:page]).per(20)
    render 'index'
  end
end
