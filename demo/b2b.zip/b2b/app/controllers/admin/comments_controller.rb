class Admin::CommentsController < Admin::ApplicationController

  def index
    @comments = Comment.includes(:merchant).order('id desc').page(params[:page]).per(20)
  end

  def destroy
    comment = Comment.find params[:id]

    if comment.delete
      redirect_to :controller => 'comments'
    else
      render json: {errors: comment.errors.full_messages.to_s}
    end
  end

end
