class Admin::ReceiptCategoriesController < Admin::ApplicationController

  def index
    @categories = ReceiptCategory.order(:id).page(params[:page]).per(20)
  end

  def create
    cate = ReceiptCategory.new data_permit
    if cate.save
      render json: {success: true}
    else
      render json: {errors: cate.errors.full_messages.to_s}
    end
  end

  def destroy
    cate = ReceiptCategory.find params[:id]

    if Company.where(receipt_category_id: cate.id).count > 0
      render json: {errors: '存在关联公司，无法删除'}
    elsif cate.delete
      render json: {success: true}
    else
      render json: {errors: cate.errors.full_messages.to_s}
    end
  end

  private
  def data_permit
    params.require(:data).permit(:name)
  end

end
