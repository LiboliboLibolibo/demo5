class Admin::MerchantsController < Admin::ApplicationController

  def index
    if @current_user.admin_role?
      @merchants = Merchant.order(:id).page(params[:page]).per(20)
    else
      @merchants = Merchant.where(customer_id: @current_user.id).order(:id).page(params[:page]).per(20)
    end
  end

  def new
    @merchant = Merchant.new
  end

  def create

    if current_user.admin_role?
      redirect_to :controller => 'merchants'
    else
      merchant = Merchant.new data_permit

      merchant["customer_id"]=current_user.id

      if merchant.save
        redirect_to :controller => 'merchants'
      else
        render json: {errors: merchant.errors.full_messages.to_s }
      end
    end

  end

  def edit
    @merchant = Merchant.find params[:id]
  end

  def update
    @merchant = Merchant.find params[:id]
    if @merchant.update(data_permit)
      redirect_to :controller => 'merchants'
    else
      render json: {errors: @merchant.errors.full_messages.to_s }
    end
  end

  def destroy
    merchant = Merchant.find params[:id]
    if merchant.delete
      redirect_to :controller => 'merchants'
    else
      render json: {errors: merchant.errors.full_messages.to_s}
    end
  end

private

  def data_permit
    params.require(:merchant).permit(Merchant.attribute_names)
  end

end
