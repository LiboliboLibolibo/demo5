class RegistersController < ApplicationController
  def create
    user = User.new params.require(:userData).permit(:name, :password)
    company = Company.new params.require(:companyData).permit(Company.attribute_names)
    address = Address.new params.require(:addressData).permit(Address.attribute_names)

    user['user_group_id'] = 7

    begin
      ActiveRecord::Base.transaction do
        if user.save!
          company['user_id'] = user.id
          if company.save!
            address['company_id'] = company.id
            if address.save!
              render json: { success: true }
            else
              render json: { errors: address.errors.full_messages.to_s }
            end
          else
            render json: { errors: company.errors.full_messages.to_s }
          end
        else
          render json: { errors: user.errors.full_messages.to_s }
          end
      end
    rescue Exception => e
      render json: { errors: e.message }
    end
    end
end
