class TradesController < ApplicationController
  def create
    merchant_infos = params[:merchant_infos]

    if current_user.admin_role?
      render json: { errors: "\u7BA1\u7406\u5458\u65E0\u6CD5\u8D2D\u4E70" } # #管理员无法购买
      return
    end

    if current_user.customer_role?
      render json: { errors: "\u9500\u552E\u5458\u65E0\u6CD5\u8D2D\u4E70" } # #销售员无法购买
      return
    end

    begin
      ActiveRecord::Base.transaction do
        total_cost = 0
        trade = nil

        merchant_infos.each do |_k, m|
          merchant = Merchant.find m[:merchant_id]

          if merchant.nil?
            raise "\u6DFB\u52A0\u5546\u54C1\u4E0D\u5B58\u5728" # 商品不存在
          elsif merchant.stock_count < m.count
            raise "\u6DFB\u52A0\u5546\u54C1\u5E93\u5B58\u4E0D\u8DB3" # 添加商品库存不足
          else

            if trade.nil?
              trade = Trade.find_or_create_by(user_id: current_user.id, status_id: 1, customer_id: merchant.customer_id)
            end

            count = m[:count].to_i

            total_cost += merchant.price * count
            trade_merchant = TradeMerchant.new(trade_id: trade.id, totals: count, merchant_id: merchant.id, unit_price: merchant.price)
            trade_merchant.save

            trade.customer_id ||= merchant.customer_id

            # 减去库存
            merchant.stock_count = merchant.stock_count - count
            merchant.save
          end
        end

        if current_user.user_profile.balance < total_cost
          raise "\u4F59\u989D\u4E0D\u8DB3" # 余额不足
        else

          profile = current_user.user_profile

          # 扣款
          profile.balance = profile.balance - total_cost
          profile.save

          # 保存订单
          trade.total_price += total_cost
          trade.status_id = 2
          trade.save
        end

        render json: { success: true }
      end
    rescue Exception => e
      render json: { errors: e.message }
      return
    end
  end

  # 支付
  def pay

    trade = nil
    re = check_trade 1 # 只处理状态为未支付的订单

    if re[:trade].nil?
      render json: re[:error]
      return
    else
      trade = re[:trade] # 只处理状态为未支付的订单
    end

    if current_user.customer_role?
      render json: { errors: "\u6CA1\u6709\u652F\u4ED8\u6743\u9650" } # 没有支付权限
      return
    else
      begin
          ActiveRecord::Base.transaction do
            if current_user.user_profile.balance < trade.final_price
              raise "\u4F59\u989D\u4E0D\u8DB3" # 余额不足
            else
              profile = current_user.user_profile
              profile.balance = profile.balance - trade.final_price
              trade.status_id = 2
              trade.save
              profile.save
            end
          end
        rescue Exception => e
          render json: { errors: e.message }
          return
        end
        render json: { success: true }
      end
  end

  # 2 ==> 3 出库
  def delivery

    trade = nil
    re = check_trade 2 # 只处理状态为已支付的订单

    if re[:trade].nil?
      render json: re[:error]
      return
    else
      trade = re[:trade] # 只处理状态为未支付的订单
    end

    if current_user.customer_role?
      trade.status_id = 3
      trade.save
    else
      render json: { errors: "\u6CA1\u6709\u51FA\u5E93\u6743\u9650" } # 没有出库权限
      return
    end
    render json: { success: true }
  end

  # 3 ==> 4 收货
  def received
    trade = nil
    re = check_trade 3 # 只处理状态为已出库的订单

    if re[:trade].nil?
      render json: re[:error]
      return
    else
      trade = re[:trade] # 只处理状态为未支付的订单
    end

    if current_user.customer_role?
      render json: { errors: "\u6CA1\u6709\u6536\u8D27\u6743\u9650" } # 没有收货权限
      return
    else
      trade.status_id = 4
      trade.save
    end
    render json: { success: true }
  end

  # 4 ==> 5 已收到退货
  def received_back

    trade = nil
    re = check_trade 4 # 只处理状态为已收货的订单

    if re[:trade].nil?
      render json: re[:error]
      return
    else
      trade = re[:trade] # 只处理状态为未支付的订单
    end

    if current_user.customer_role?
      trade.status_id = 5
      trade.save
    else
      render json: { errors: "\u6CA1\u6709\u6536\u5230\u9000\u8D27\u6743\u9650" } # 没有收到退货权限
      return
    end
    render json: { success: true }
  end

  def destroy
    trade = Trade.find params[:id]

    if trade.nil?
      render json: { errors: "\u8BA2\u5355\u4E0D\u5B58\u5728" } # 订单不存在
      return
    end

    case trade.status_id
    when 1
      if current_user.customer_role?
        render json: { errors: "\u6CA1\u6709\u64A4\u9500\u6743\u9650" } # 没有撤销权限
        return
      else
        begin
            ActiveRecord::Base.transaction do
              trade.trade_merchant do |tm|
                # 返还库存
                tm.merchant.stock_count = tm.merchant.stock_count + tm.totals
                tm.merchant.save

                # 删除订单
                tm.delete
              end

              trade.delete
            end
          rescue Exception => e
            render json: { errors: e.message }
          end
      end
    when 2
      if current_user.customer_role?
        render json: { errors: "\u6CA1\u6709\u64A4\u9500\u6743\u9650" } # 没有撤销权限
        return
      else
        begin
            ActiveRecord::Base.transaction do
              trade.trade_merchant do |tm|
                # 返还库存
                tm.merchant.stock_count = tm.merchant.stock_count + tm.totals
                tm.merchant.save

                tm.delete
              end

              # 返还余额
              trade.user.user_profile.balance = trade.user.user_profile.balance + trade.final_price
              trade.user.user_profile.save

              # 删除订单
              trade.delete
            end
          rescue Exception => e
            render json: { errors: e.message }
          end
      end
    else
      render json: { errors: "\u65E0\u6CD5\u64A4\u9500\u8BA2\u5355" } # 无法撤销订单
      return
    end
    render json: { success: true }
  end

  private

  def check_trade(status_id)
    trade = Trade.find params[:format]

    resualt = {}

    if trade.nil?
      resualt[:error] = { errors: "\u8BA2\u5355\u4E0D\u5B58\u5728" }  # 订单不存在
      return resualt
    end

    unless trade.user_id == current_user.id || trade.customer_id == current_user.id
      resualt[:error] = { errors: "\u64CD\u4F5C\u7528\u6237\u4E0D\u5408\u6CD5" }  # 操作用户不合法
      return resualt
    end

    unless trade.status_id == status_id
      resualt[:error] = { errors: "\u8BA2\u5355\u72B6\u6001\u4E0D\u5408\u6CD5" }  # 订单状态不合法
      return resualt
    end

    resualt[:trade] = trade

    return resualt
  end
end
