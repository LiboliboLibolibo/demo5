class MerchantTradesController < ApplicationController
  def create
    merchant_infos = params[:merchant_infos]

    if current_user.admin_role?
      render json: { errors: "\u7BA1\u7406\u5458\u65E0\u6CD5\u8D2D\u4E70" }
      return
    end

    if current_user.customer_role?
      render json: { errors: "\u9500\u552E\u5458\u65E0\u6CD5\u8D2D\u4E70" } # #销售员无法购买
      return
    end

    begin
      ActiveRecord::Base.transaction do
        total_cost = 0
        trade = nil

        merchant_infos.each do |_k, m|
          merchant = Merchant.find m[:merchant_id]
          count = m[:count].to_i

          if trade.nil?
            trade = Trade.find_or_create_by(user_id: current_user.id, status_id: 1, customer_id: merchant.customer_id)
          end

          if merchant.nil?
            raise "\u6DFB\u52A0\u5546\u54C1\u4E0D\u5B58\u5728" # 添加商品不存在
          elsif merchant.stock_count < count
            raise "\u6DFB\u52A0\u5546\u54C1\u5E93\u5B58\u4E0D\u8DB3" # 添加商品库存不足
          else
            total_cost += merchant.price * count
            trade_merchant = TradeMerchant.find_or_create_by(trade_id: trade.id, merchant_id: m[:merchant_id])

            trade_merchant.totals += count
            trade_merchant.unit_price = merchant.price

            trade_merchant.save

            # 减去库存
            merchant.stock_count = merchant.stock_count - count
            merchant.save
          end
        end

        trade.total_price += total_cost
        trade.final_price = trade.total_price
        trade.save

        render json: { success: true }
      end
    rescue Exception => e
      render json: { errors: e.message }
    end
    end
end
