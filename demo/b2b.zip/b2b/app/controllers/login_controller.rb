class LoginController < ApplicationController
  def index

  end

  def create
    user = User.find_by(name: params[:user_name]).try(:authenticate, params[:password])
    if user
      if user.verify? && !user.admin_role?
        redirect_to :controller => 'users',:action=>"login",:notice=>'用户未审核通过，请联系管理员'
      else
        session[:user_id] = user.id
        redirect_to :controller => 'merchants',:action=>"welcome"
      end
    else
      p params[:password]
      redirect_to :controller => 'users',:action=>"login",:notice=>'用户名和密码不匹配'
    end
  end

  def logout
    session[:user_id] = nil
    redirect_to  login_users_path
  end
end
