module ShoppingsHelper
end
