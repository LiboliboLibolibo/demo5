module TradesHelper
end
