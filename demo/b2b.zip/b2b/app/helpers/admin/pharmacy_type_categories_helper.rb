module Admin::PharmacyTypeCategoriesHelper
end
