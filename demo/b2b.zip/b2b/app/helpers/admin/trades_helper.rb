module Admin::TradesHelper
end
