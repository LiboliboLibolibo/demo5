module Admin::AdvertsHelper
end
