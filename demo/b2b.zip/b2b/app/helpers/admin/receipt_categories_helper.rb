module Admin::ReceiptCategoriesHelper
end
