module Admin::ScopeCategoriesHelper
end
