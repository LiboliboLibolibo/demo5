class SellCategory < ApplicationRecord
  has_many :merchant
end
