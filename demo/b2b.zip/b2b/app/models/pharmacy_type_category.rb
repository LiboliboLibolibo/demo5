class PharmacyTypeCategory < ApplicationRecord
  has_many :merchant
end
