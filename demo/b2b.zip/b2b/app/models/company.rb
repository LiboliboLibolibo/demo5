class Company < ApplicationRecord

  belongs_to :user
  belongs_to :company_category
  belongs_to :receipt_category

  has_many  :company_scope
  has_many  :address

  after_initialize :default_value


  private
  def default_value
    self.company_category_id ||= 1
    self.receipt_category_id ||= 1
  end

end
