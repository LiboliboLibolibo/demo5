class User < ApplicationRecord
  has_secure_password

  validates :name, presence:  { message: '缺少用户名' }
  validates :user_group_id, presence:  { message: '缺少用户组' }
  validates :name, uniqueness: { message: '用户名重复' }

  belongs_to :user_group

  has_one :company
  has_one :user_profile
  has_many :user_brand
  has_many :comment

  has_and_belongs_to_many :brand

  before_create :default_value
  after_create  :create_relations

  def self.status
    {
      1 => { id: 1, name: '审核中' },
      2 => { id: 2, name: '正常' }
    }
  end

  def status
    self.class.status[status_id]
  end

  def admin_role?
    user_group_id == 1
  end

  def customer_role?
    user_group_id == 4
  end

  def verify?
    status_id == 1
  end

  def self.admin
    where(user_group_id: 1)
  end

  def self.customer
    where(user_group_id: 4)
  end

  def self.terminal
    where(user_group_id: [6, 7])
  end

  private

  def default_value
    self.user_group_id ||= 7
    self.status_id ||= 1
  end

  def create_relations
    # Company.create user_id: self.id
    UserProfile.create user_id: id
  end
end
