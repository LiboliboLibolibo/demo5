class Brand < ApplicationRecord

    has_many :merchant

    # validates :name                           , presence:  {message: '缺少品牌名称'}
    # validates :decription                     , presence:  {message: '缺少品牌描述'}
    # validates :logo                           , presence:  {message: '缺少品牌LOGO'}

    mount_uploader :logo, AdvertUploader

end
