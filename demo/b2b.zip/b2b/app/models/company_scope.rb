class CompanyScope < ApplicationRecord

  belongs_to :company
  belongs_to :scope_category

end
