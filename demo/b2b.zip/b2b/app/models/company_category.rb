class CompanyCategory < ApplicationRecord

  has_many  :company

end
