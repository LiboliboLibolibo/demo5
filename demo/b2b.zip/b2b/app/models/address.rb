class Address < ApplicationRecord

  belongs_to :company

  validates :company_id                   , presence:  {message: '缺少公司关联'}
  validates :receiver                     , presence:  {message: '缺少收货人'}
  validates :phone                        , presence:  {message: '缺少电话'}
  validates :province                     , presence:  {message: '缺少省份'}
  validates :city                         , presence:  {message: '缺少城市'}
  validates :area                         , presence:  {message: '缺少区域'}
  validates :street                       , presence:  {message: '缺少街道'}
  validates :post_code                    , presence:  {message: '缺少邮政编码'}

end
