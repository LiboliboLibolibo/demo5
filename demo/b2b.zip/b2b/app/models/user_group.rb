class UserGroup < ApplicationRecord
  has_many  :user
end
