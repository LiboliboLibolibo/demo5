class Article < ApplicationRecord
end
