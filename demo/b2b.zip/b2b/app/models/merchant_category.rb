class MerchantCategory < ApplicationRecord

  has_many :merchant

  before_create :default_value

  def parent
    self.class.find_by(id: self.parent_id)
  end

  private
  def default_value
    self.parent_id ||= 0
  end

end
