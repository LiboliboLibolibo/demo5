class Comment < ApplicationRecord
    belongs_to  :user , -> { includes :user }
    belongs_to  :trade, -> { includes :trade }
    belongs_to  :merchant, -> { includes :merchant }
end
