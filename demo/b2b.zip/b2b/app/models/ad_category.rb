class AdCategory < ApplicationRecord
  has_many  :ad

  validates :ad_type        , presence:  {message: '缺少广告类型描述'}
  validates :position       , uniqueness: {message: ' 广告位置重复'}

end
