class UserProfile < ApplicationRecord

  belongs_to :user

  after_initialize :default_value

  def pay(money)
    self.balance = self.balance - money
  end

  private
  def default_value
    self.balance ||= 0
    self.point ||= 0
    self.quota ||= 0
  end

end
