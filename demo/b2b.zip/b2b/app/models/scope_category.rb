class ScopeCategory < ApplicationRecord

  has_many  :company_scope
  
end
