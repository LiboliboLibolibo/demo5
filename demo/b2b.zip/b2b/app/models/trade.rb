class Trade < ApplicationRecord
  belongs_to  :user
  belongs_to  :customer, class_name: 'User'
  has_many    :trade_merchant
  has_many    :comment

  after_initialize :default_values

  def self.status
    {
      1 => { id: 1, name: '待支付' },
      2 => { id: 2, name: '已支付' },
      3 => { id: 3, name: '已出库' },
      4 => { id: 4, name: '已收货' },
      5 => { id: 5, name: '已退货' }
    }
  end

  def status
    self.class.status[status_id][:name]
  end

  private

  def default_values
    self.status_id ||= 1
    self.total_price ||= 0
    self.final_price ||= 0
  end
end
