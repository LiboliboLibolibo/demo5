class ReceiptCategory < ApplicationRecord

  has_many  :company

end
