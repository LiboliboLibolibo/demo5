class Ad < ApplicationRecord

  belongs_to :ad_category

  validates :pic                   , presence:  {message: '缺少广告图片'}
  validates :url                   , presence:  {message: '缺少广告跳转链接'}
  validates :ad_category_id        , presence:  {message: '缺少广告类别'}

  mount_uploader :pic, AdvertUploader


end
