class TradeMerchant < ApplicationRecord
  belongs_to  :trade
  belongs_to  :merchant

  after_initialize :default_value

  private

  def default_value
    self.totals ||= 0
    self.unit_price ||= 0
  end
end
