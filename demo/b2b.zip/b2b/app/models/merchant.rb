class Merchant < ApplicationRecord

  belongs_to :brand
  belongs_to :merchant_category
  belongs_to :pharmacy_type_category
  belongs_to :sell_category

  has_many    :comment , -> { includes :comments }
  has_many    :trade_merchant

  before_create :default_value

  mount_uploader :picture, MerchantUploader


  def self.status
    {
      1 => {id: 1 , name: '上架'} ,
      2 => {id: 2 , name: '下架'}
    }
  end

  def self.is_otc
    {
      1 => {id: 1 , name: '是'} ,
      2 => {id: 2 , name: '否'}
    }
  end

  def is_otc
    self.is_otc[self.otc]
  end

  def self.show_otc
    self.is_otc.map{|k,v| [v[:name] ,v[:id]]}
  end


  def status
    self.class.status[self.status_id]
  end

  def self.show_status
    self.status.map{|k,v| [v[:name] ,v[:id]]}
  end

private
  def default_value
    self.status_id ||= 1
  end

end
